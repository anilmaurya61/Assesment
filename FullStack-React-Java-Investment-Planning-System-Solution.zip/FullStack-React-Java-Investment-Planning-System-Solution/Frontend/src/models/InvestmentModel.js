export default class Investment {
    constructor(id, name, amount, date, category) {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.date = date;
        this.category = category;
    }
}
